<meta charset="UTF-8">
<?php
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// 資料庫連線
$conn = new PDO("mysql:host=localhost;dbname=user", "db_username", "db_password"); //資料庫的使用者及密碼
$conn->exec("SET NAMES utf8");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = htmlspecialchars($_POST["name"]);
    $email = filter_var($_POST["email"], FILTER_VALIDATE_EMAIL);
    $photo = $_FILES["photo"]["name"];
    $target = "uploads/" . basename($photo);

    if (!$email) {
        die("Email 格式錯誤！");
    }
    
    $checkStmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
    $checkStmt->execute([$email]);
    if ($checkStmt->fetchColumn() > 0) {
        echo "此 Email 已經註冊過，請使用其他 Email。";
        header("Refresh:3");
        exit;
    }

    if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target)) {
        $stmt = $conn->prepare("INSERT INTO users (name, email, photo) VALUES (?, ?, ?)");
        if ($stmt->execute([$name, $email, $photo])) {
            $lastId = $conn->lastInsertId();
            header("Location: sendMail.php?id=" . $lastId);
            exit;
        } else {
            echo "寫入資料庫失敗";
        }
    } else {
        echo "照片上傳失敗";
    }
}
?>

<!-- HTML 表單區塊 -->
<form method="POST" enctype="multipart/form-data">
    姓名: <input type="text" name="name" required><br>
    Email: <input type="email" name="email" required><br>
    照片: <input type="file" name="photo" accept="image/*" required><br>
    <input type="submit" value="Register">
</form>