<meta charset="UTF-8">
<?php
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// 資料庫連線
$conn = new PDO("mysql:host=localhost;dbname=user", "root", "moon2j1605");
$conn->exec("SET NAMES utf8");

$id = $_GET['id'] ?? null;

if ($id) {
    $stmt = $conn->prepare("SELECT name, email, photo FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $name = $user['name'];
        $email = $user['email'];
        $photo = $user['photo'];
        $photoPath = "uploads/" . $photo;

        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'l1873490@gmail.com'; // 改成你的 Gmail
            $mail->Password = 'eych prus bgin whyk'; // 使用 Gmail App 密碼
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            $mail->Port = 465;
            $mail->Charset = 'UTF-8';

            $mail->setFrom('l1873490@gmail.com', mb_encode_mimeheader('註冊系統', 'UTF-8'));
            $mail->addAddress($email);

            $mail->addEmbeddedImage($photoPath, 'userphoto');

            $subject = "恭喜註冊成功";
            $content = "恭喜註冊成功<br><img src='cid:userphoto' style='width:200px;'>";

            $mail->isHTML(true);
            $mail->Subject = "=?UTF-8?B?" . base64_encode($subject) . "?=";
            $mail->Body = $content;

            $mail->send();
            echo "寄信成功！";
        } catch (Exception $e) {
            echo "寄信失敗：" . $mail->ErrorInfo;
        }
    } else {
        echo "查無資料";
    }
} else {
    echo "缺少 id 參數";
}