<?php
// logout.php
session_start();
if (isset($_SESSION['role'])) {
    setcookie("last_role", $_SESSION['role'], time() + 60, "/"); // 存 60 秒
}
session_destroy();
setcookie("last_user", "", time() - 3600, "/");
header("Location: login.php");
exit();
?>