<?php
session_start();
$welcome_message = "";

if (isset($_COOKIE['last_role'])) {
    $last_role = $_COOKIE['last_role'];
    $welcome_message = "Welcome back, " . ucfirst($last_role) . "!";
    setcookie("last_role", "", time() - 3600, "/"); // 立即刪除 Cookie
}
?>




<h1>請登入以填寫報名表單</h1>
<?php if ($welcome_message): ?>
        <p style="color: green;"><?php echo $welcome_message; ?></p>
<?php endif; ?>
<form action="logincheck.php" method="post">
please input your account : <input type="text", name = "name">
please input your password : <input type="text", name = "password">
<input type="submit">
</form>