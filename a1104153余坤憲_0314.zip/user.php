<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== "user") {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>User Page</title>
</head>
<body>
    <h2>Welcome User</h2>
    <a href="logout.php">Logout</a>
</body>
</html>
