
<?php
session_start();
$username = $_POST["name"];
$userpwd = $_POST["password"];

// 簡單的帳號密碼檢查
if ($username === "admin" && $userpwd === "admin123") {
    $_SESSION['username'] = $username; // 設定 session
    $_SESSION['role'] = "admin"; // 設定角色
    header("Location: admin.php");
    exit();
} elseif ($username === "user" && $userpwd === "user123") {
    $_SESSION['username'] = $username;
    $_SESSION['role'] = "user";
    header("Location: user.php");
    exit();
} else {
    echo "登入失敗";
}
?>