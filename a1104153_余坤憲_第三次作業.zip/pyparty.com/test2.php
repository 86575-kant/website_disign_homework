<html>
    <head>
        <title>接收資料</title>
        <meta charset="UTF-8">
    </head>
    <body>
        <?php
        $get_value1 = $_GET['name'];
        $get_value2 = $_GET['student_id'];
        echo "姓名 :".$get_value1."學號 :".$get_value2;
        ?>
    </body>
</html>